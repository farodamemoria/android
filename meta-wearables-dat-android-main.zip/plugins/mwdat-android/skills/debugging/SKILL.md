---
name: debugging
description: Common issues, Developer Mode, version compatibility, and session and stream diagnosis
---

# Debugging (Android)

Diagnose common setup, session, and stream issues in DAT SDK integrations.

If local DAT Inspector MCP tools are available, use the `live-debugging-mcp`
skill before changing app code. Prefer `get_dat_readiness`,
`get_companion_boundary_diagnosis`, and `get_device_path` to separate app bugs from
Meta AI app/device boundary issues using read-only DAT evidence.

## Quick diagnosis

```text
No eligible device or session won't start?
|
+-- Did you call Wearables.initialize(context)? -> Must happen before SDK usage
|
+-- Did registration complete? -> Observe Wearables.registrationState
|
+-- Is Developer Mode enabled? -> Enable it in the Meta AI app for dev builds
|
+-- Does Wearables.devices contain a linked device? -> Check Bluetooth and range
|
+-- Did createSession() or addCamera() return a DatResult failure? -> Surface the typed error
```

## Developer Mode

Developer Mode must be enabled for local development builds that use `mwdat_application_id = 0` and `mwdat_client_token = 0`.

### Symptoms when Developer Mode is disabled

- Registration flow completes but the device never becomes eligible
- Permission requests do not succeed for development builds
- `Wearables.createSession(...)` fails with no eligible device

### Watch for

- Developer Mode may reset after app or firmware updates
- Developer Mode is configured per linked device
- Production builds use a real `APPLICATION_ID`, `CLIENT_TOKEN`, and release-channel gating instead

## Session and stream issues

### Session never reaches `STARTED`

- Verify `Wearables.registrationState`
- Check that `Wearables.devices` contains a compatible linked device
- Ensure the glasses are powered on, unfolded, and in range

### Stream never reaches `STREAMING`

- Confirm `session.start()` succeeded before calling `session.addCamera(...)`
- Check camera permission status through `Wearables.checkPermissionStatus(...)`
- Make sure `camera.stream.start()` returned success

### Photo capture fails

- `capturePhoto()` only succeeds while the stream is actively streaming
- Surface the returned `CaptureError` instead of discarding the `DatResult`

## Version compatibility

Ensure compatible versions of the SDK, Meta AI app, and glasses firmware. See [version dependencies](https://wearables.developer.meta.com/docs/version-dependencies) for the current compatibility matrix.

## Logging

```kotlin
private const val TAG = "DATWearables"

camera.stream.start()
    .onFailure { error, _ -> Log.e(TAG, "Failed to start stream: ${error.description}") }
```

Prefer logging typed `DatResult` failures and observed state transitions over generic exceptions.

## Live MCP evidence

When the developer has a local DAT debug server connected to the agent:

- Start with `get_sdk_state` and `get_dat_readiness`
- Use `get_companion_boundary_diagnosis` for permission, app identity, device
  capability, device-selection, deeplink-return, and DAM/DWA-visible blockers
- Use `get_device_path` to trace app -> DAT registration -> Meta AI app permissions ->
  device selection/link -> session -> stream
- Ask the developer to reproduce the issue, then use `wait_for_events` with the
  narrowest category or source that matches the flow
- Use `export_diagnostic_bundle` for redacted support handoff

Do not treat this as companion app introspection. It is diagnosis from
app-visible DAT debug events.

## Checklist

- [ ] `Wearables.initialize(context)` ran before SDK usage
- [ ] Developer Mode enabled for development builds
- [ ] `APPLICATION_ID` and `CLIENT_TOKEN` match the build mode
- [ ] Registration completed before session creation
- [ ] Bluetooth permission granted
- [ ] Camera permission granted through Meta AI
- [ ] Session and stream `DatResult` failures are surfaced in logs or UI

## Links

- [Known issues](https://wearables.developer.meta.com/docs/knownissues)
- [Version dependencies](https://wearables.developer.meta.com/docs/version-dependencies)
- [Troubleshooting discussions](https://github.com/facebook/meta-wearables-dat-android/discussions)
